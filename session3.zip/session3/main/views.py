from django.shortcuts import render


def home(request):
    return render(request, 'home.html')


def explore(request):
    playlists = [
        {'title': 'Top Hits 2026', 'description': 'Is saal ke sabse hit gaane.', 'image': 'https://picsum.photos/seed/a1/400/250'},
        {'title': 'Chill Vibes', 'description': 'Relax karne ke liye perfect.', 'image': 'https://picsum.photos/seed/a2/400/250'},
        {'title': 'Workout Beats', 'description': 'Gym ke liye energy booster.', 'image': 'https://picsum.photos/seed/a3/400/250'},
        {'title': 'Bollywood Classics', 'description': 'Purane aur sunehre gaane.', 'image': 'https://picsum.photos/seed/a4/400/250'},
        {'title': 'Lo-Fi Study', 'description': 'Padhai ke time focus ke liye.', 'image': 'https://picsum.photos/seed/a5/400/250'},
        {'title': 'Road Trip', 'description': 'Long drive ke best gaane.', 'image': 'https://picsum.photos/seed/a6/400/250'},
    ]
    return render(request, 'explore.html', {'playlists': playlists})


def profile(request):
    return render(request, 'profile.html')